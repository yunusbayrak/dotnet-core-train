﻿namespace MVC.Settings
{
    public class AppSettings
    {
        public static string NoRecordsFound { get; set; }
        public static string RecordsFound { get; set; }
    }
}
