﻿using Business.Models;
using System.Collections.Generic;

namespace MVC.Models
{
    public class OlayIndexViewModel
    {
        public List<OlayModel> Olaylar { get; set; }
    }
}
