﻿using Business.Models;

namespace MVC.Models
{
    public class IslemDurumuEditViewModel
    {
        public IslemDurumuModel IslemDurumu { get; set; }
    }
}
