﻿using Business.Models;

namespace MVC.Models
{
    public class OlayDeleteViewModel
    {
        public OlayModel Olay { get; set; }
    }
}
