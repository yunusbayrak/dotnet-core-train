﻿using System.Collections.Generic;
using Business.Models;

namespace MVC.Models
{
    public class IslemDurumuIndexViewModel
    {
        public List<IslemDurumuModel> IslemDurumlari { get; set; }
    }
}
