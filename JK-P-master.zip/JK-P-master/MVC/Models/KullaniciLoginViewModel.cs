﻿using Business.Models;

namespace MVC.Models
{
    public class KullaniciLoginViewModel
    {
        public KullaniciModel Kullanici { get; set; }
    }
}
