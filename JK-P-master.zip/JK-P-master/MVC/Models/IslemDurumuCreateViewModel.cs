﻿using Business.Models;

namespace MVC.Models
{
    public class IslemDurumuCreateViewModel
    {
        public IslemDurumuModel IslemDurumu { get; set; }
    }
}
