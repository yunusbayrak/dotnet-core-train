﻿using Business.Models;

namespace MVC.Models
{
    public class OlayDetailsViewModel
    {
        public OlayModel Olay { get; set; }
    }
}
