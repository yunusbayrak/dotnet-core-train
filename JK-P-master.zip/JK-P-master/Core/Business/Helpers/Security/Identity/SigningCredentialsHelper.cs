﻿using Core.Business.Helpers.Security.Identity.Bases;

namespace Core.Business.Helpers.Security.Identity
{
    public class SigningCredentialsHelper : SigningCredentialsHelperBase
    {

    }
}
