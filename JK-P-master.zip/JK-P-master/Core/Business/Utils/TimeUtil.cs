﻿using Core.Business.Utils.Bases;

namespace Core.Business.Utils
{
    public class TimeUtil : TimeUtilBase
    {
        
    }
}
