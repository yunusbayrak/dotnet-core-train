﻿using Core.Business.Utils.Security.Identity.Bases;

namespace Core.Business.Utils.Security.Identity
{
    public class JwtUtil : JwtUtilBase
    {
    }
}
