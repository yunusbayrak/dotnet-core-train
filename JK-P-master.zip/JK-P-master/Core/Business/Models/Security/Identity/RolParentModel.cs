﻿using Core.Business.Models.Security.Identity.Bases;

namespace Core.Business.Models.Security.Identity
{
    public class RolParentModel : RolModelBase
    {

    }
}
