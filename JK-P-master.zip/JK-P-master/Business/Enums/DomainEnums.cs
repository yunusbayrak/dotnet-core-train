﻿namespace Business.Enums
{
    public enum RolEnum
    {
        Admin = 1,
        Kullanici = 2
    }
}
