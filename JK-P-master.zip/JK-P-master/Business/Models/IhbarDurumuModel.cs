﻿using Core.Records.Bases;

namespace Business.Models
{
    public class IhbarDurumuModel : RecordBase
    {
        public string Adi { get; set; }
    }
}
