﻿using Core.Business.Models.Security.Identity;

namespace Business.Models
{
    public class RolModel : RolParentModel
    {
        
    }
}
