﻿using Entity.Entities;

namespace Business.Services.Bases
{
    public interface IFaaliyetService
    {
        void AddFaaliyet(Faaliyet faaliyet);
    }
}
