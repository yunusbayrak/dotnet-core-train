﻿using Business.Models;

namespace Business.Services.Bases
{
    public interface IRolService
    {
        void AddRol(RolModel rol);
    }
}
