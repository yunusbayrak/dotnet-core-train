﻿using Entity.Entities;

namespace Business.Services.Bases
{
    public interface IOlayIhbarService
    {
        void AddOlayIhbar(OlayIhbar olayIhbar);
    }
}
