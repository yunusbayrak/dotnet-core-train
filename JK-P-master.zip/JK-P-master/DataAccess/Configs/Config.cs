﻿namespace DataAccess.Configs
{
    public static class Config
    {
        public static string ConnectionString { get; set; }
    }
}
